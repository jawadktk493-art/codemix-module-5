// Supabase dashboard > Project Settings > API se values yahan paste karo
const SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
const SUPABASE_ANON_KEY = "YOUR-ANON-KEY";
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
