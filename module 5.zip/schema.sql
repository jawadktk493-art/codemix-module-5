-- Supabase > SQL Editor me run karo (agar blogs table pehle se hai to sirf user_id + policies wala hissa)
create table if not exists public.blogs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  content text not null,
  category text,
  user_id uuid references auth.users(id) on delete cascade default auth.uid(),
  created_at timestamptz default now()
);
alter table public.blogs enable row level security;
create policy "public read" on public.blogs for select using (true);
create policy "owner insert" on public.blogs for insert with check (auth.uid() = user_id);
create policy "owner update" on public.blogs for update using (auth.uid() = user_id);
create policy "owner delete" on public.blogs for delete using (auth.uid() = user_id);
